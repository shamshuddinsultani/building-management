A Pen created at CodePen.io. You can find this one at https://codepen.io/rkpasia/pen/LNEQod.

 A concept for an interactive signup form. I've taken the inspiration by this shot https://dribbble.com/shots/2372516--5-Subscribe-Form

Hope you enjoy :)